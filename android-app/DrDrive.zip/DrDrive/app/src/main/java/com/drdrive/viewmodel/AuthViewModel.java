package com.drdrive.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.drdrive.utils.SessionManager;

/**
 * AuthViewModel — handles login and register calls.
 * Full Retrofit wiring added in Step 4.
 */
public class AuthViewModel extends AndroidViewModel {

    public static class AuthResult {
        private final boolean success;
        private final String  error;
        public AuthResult(boolean success, String error) { this.success = success; this.error = error; }
        public boolean isSuccess() { return success; }
        public String  getError()  { return error; }
    }

    private final MutableLiveData<AuthResult> loginResult    = new MutableLiveData<>();
    private final MutableLiveData<AuthResult> registerResult = new MutableLiveData<>();
    private final SessionManager              session;

    public AuthViewModel(@NonNull Application application) {
        super(application);
        session = new SessionManager(application);
    }

    public void login(String email, String password) {
        // TODO Step 4: AuthRepository.login(email, password)
        //   on success: session.saveSession(token, name, email)
        //              loginResult.postValue(new AuthResult(true, null))
        //   on failure: loginResult.postValue(new AuthResult(false, errorMsg))

        // Stub: accept any credentials for now
        session.saveSession("stub_token", "Test User", email);
        loginResult.setValue(new AuthResult(true, null));
    }

    public void register(String name, String email, String password) {
        // TODO Step 4: AuthRepository.register(name, email, password)

        // Stub
        registerResult.setValue(new AuthResult(true, null));
    }

    public LiveData<AuthResult> getLoginResult()    { return loginResult; }
    public LiveData<AuthResult> getRegisterResult() { return registerResult; }
}
