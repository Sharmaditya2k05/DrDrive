package com.drdrive.model;

import com.google.gson.annotations.SerializedName;

/** Car valuation + repair cost output from the backend scoring engine. */
public class Valuation {

    @SerializedName("fair_market_value")  private long    fairMarketValue;
    @SerializedName("repair_cost_min")    private long    repairCostMin;
    @SerializedName("repair_cost_max")    private long    repairCostMax;
    @SerializedName("adjusted_value")     private long    adjustedValue;
    @SerializedName("depreciation_pct")   private float   depreciationPct;
    @SerializedName("fraud_suspected")    private boolean fraudSuspected;
    @SerializedName("fraud_reason")       private String  fraudReason;
    @SerializedName("city")               private String  city;
    @SerializedName("recommendation")     private String  recommendation; // "Buy" | "Negotiate" | "Avoid"

    public long    getFairMarketValue()  { return fairMarketValue; }
    public long    getRepairCostMin()    { return repairCostMin; }
    public long    getRepairCostMax()    { return repairCostMax; }
    public long    getAdjustedValue()    { return adjustedValue; }
    public float   getDepreciationPct()  { return depreciationPct; }
    public boolean isFraudSuspected()    { return fraudSuspected; }
    public String  getFraudReason()      { return fraudReason; }
    public String  getCity()             { return city; }
    public String  getRecommendation()   { return recommendation; }

    public void setFairMarketValue(long v)    { fairMarketValue = v; }
    public void setRepairCostMin(long v)      { repairCostMin = v; }
    public void setRepairCostMax(long v)      { repairCostMax = v; }
    public void setAdjustedValue(long v)      { adjustedValue = v; }
    public void setDepreciationPct(float v)   { depreciationPct = v; }
    public void setFraudSuspected(boolean v)  { fraudSuspected = v; }
    public void setFraudReason(String v)      { fraudReason = v; }
    public void setCity(String v)             { city = v; }
    public void setRecommendation(String v)   { recommendation = v; }
}
