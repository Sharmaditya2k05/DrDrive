package com.drdrive.ui.obd;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.drdrive.databinding.ActivityObdScanBinding;
import com.drdrive.ui.camera.CameraActivity;
import com.drdrive.utils.PermissionHelper;
import com.drdrive.viewmodel.OBDViewModel;

/**
 * OBDScanActivity — step 1 of the inspection flow.
 * Discovers ELM327 devices via Bluetooth, runs scan, then launches Camera.
 * Full ELM327 implementation added in Step 3 (OBD module).
 */
public class OBDScanActivity extends AppCompatActivity {

    public static final String EXTRA_QUICK_MODE = "quick_mode";

    private ActivityObdScanBinding binding;
    private OBDViewModel obdViewModel;
    private PermissionHelper permissionHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityObdScanBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Connect to Car");
        }

        obdViewModel  = new ViewModelProvider(this).get(OBDViewModel.class);
        permissionHelper = new PermissionHelper(this);

        setupClickListeners();
        observeViewModel();
        checkPermissionsAndScan();
    }

    private void checkPermissionsAndScan() {
        permissionHelper.requestBluetoothPermissions(granted -> {
            if (granted) {
                obdViewModel.startDeviceDiscovery();
            } else {
                Toast.makeText(this,
                        "Bluetooth permission required to connect to OBD adapter",
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    private void setupClickListeners() {
        binding.btnStartScan.setOnClickListener(v -> obdViewModel.startDeviceDiscovery());

        binding.btnSkipObd.setOnClickListener(v -> {
            // Allow visual-only inspection (no OBD data)
            launchCamera(null);
        });

        binding.btnConnect.setOnClickListener(v -> {
            String selectedDevice = obdViewModel.getSelectedDevice().getValue();
            if (selectedDevice != null) {
                binding.progressScanning.setVisibility(View.VISIBLE);
                obdViewModel.connectToDevice(selectedDevice);
            }
        });
    }

    private void observeViewModel() {
        // Connection state
        obdViewModel.getConnectionState().observe(this, state -> {
            switch (state) {
                case SCANNING:
                    binding.tvStatus.setText("Scanning for OBD devices...");
                    binding.progressScanning.setVisibility(View.VISIBLE);
                    binding.btnConnect.setEnabled(false);
                    break;
                case CONNECTED:
                    binding.tvStatus.setText("Connected! Reading data...");
                    binding.progressScanning.setVisibility(View.VISIBLE);
                    break;
                case COMPLETE:
                    binding.progressScanning.setVisibility(View.GONE);
                    binding.tvStatus.setText("OBD scan complete");
                    launchCamera(obdViewModel.getObdSessionId());
                    break;
                case ERROR:
                    binding.progressScanning.setVisibility(View.GONE);
                    binding.tvStatus.setText("Connection failed. Try again.");
                    break;
                case IDLE:
                default:
                    binding.tvStatus.setText("Tap 'Scan' to find OBD adapter");
                    binding.progressScanning.setVisibility(View.GONE);
            }
        });

        // Device list for picker dialog
        obdViewModel.getDiscoveredDevices().observe(this, devices -> {
            if (devices != null && !devices.isEmpty()) {
                binding.btnConnect.setEnabled(true);
                binding.tvDeviceCount.setText(devices.size() + " device(s) found");
                // Full device picker dialog in Step 3
            }
        });

        // Live OBD readings display
        obdViewModel.getLiveReadings().observe(this, reading -> {
            if (reading != null) {
                binding.tvRpm.setText(String.valueOf(reading.getRpm()));
                binding.tvCoolant.setText(reading.getCoolantTemp() + "°C");
                binding.tvSpeed.setText(reading.getSpeed() + " km/h");
                binding.tvBattery.setText(reading.getBatteryVoltage() + "V");
            }
        });
    }

    private void launchCamera(String obdSessionId) {
        Intent intent = new Intent(this, CameraActivity.class);
        if (obdSessionId != null) {
            intent.putExtra(CameraActivity.EXTRA_OBD_SESSION_ID, obdSessionId);
        }
        startActivity(intent);
        // Don't finish — user may need to come back
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
