package com.drdrive.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.drdrive.database.entity.InspectionEntity;

import java.util.List;

/**
 * InspectionDao — Room DAO for local inspection cache.
 */
@Dao
public interface InspectionDao {

    // ── Write ─────────────────────────────────────────────────

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(InspectionEntity entity);

    @Update
    void update(InspectionEntity entity);

    @Delete
    void delete(InspectionEntity entity);

    // ── Read ──────────────────────────────────────────────────

    @Query("SELECT * FROM inspections ORDER BY created_at DESC")
    LiveData<List<InspectionEntity>> getAllInspections();

    @Query("SELECT * FROM inspections ORDER BY created_at DESC LIMIT 3")
    LiveData<List<InspectionEntity>> getRecentInspections();

    @Query("SELECT * FROM inspections WHERE report_id = :id LIMIT 1")
    InspectionEntity getById(String id);

    @Query("SELECT * FROM inspections WHERE synced = 0")
    List<InspectionEntity> getUnsynced();

    @Query("SELECT COUNT(*) FROM inspections")
    int getTotalCount();

    @Query("DELETE FROM inspections")
    void deleteAll();
}
