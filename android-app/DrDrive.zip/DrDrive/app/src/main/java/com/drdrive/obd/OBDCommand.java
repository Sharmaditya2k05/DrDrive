package com.drdrive.obd;

/**
 * OBDCommand — every OBD-II PID the app reads.
 * Each command knows its hex code, how to parse the raw bytes,
 * and what unit to display.
 */
public enum OBDCommand {

    ENGINE_RPM(
            "010C",
            "Engine RPM",
            "RPM",
            response -> {
                int[] bytes = OBDParser.parseBytes(response, 2);
                return ((bytes[0] * 256) + bytes[1]) / 4.0f;
            }),

    VEHICLE_SPEED(
            "010D",
            "Vehicle Speed",
            "km/h",
            response -> (float) OBDParser.parseBytes(response, 1)[0]),

    COOLANT_TEMP(
            "0105",
            "Coolant Temperature",
            "°C",
            response -> (float) (OBDParser.parseBytes(response, 1)[0] - 40)),

    ENGINE_LOAD(
            "0104",
            "Engine Load",
            "%",
            response -> OBDParser.parseBytes(response, 1)[0] * 100.0f / 255.0f),

    THROTTLE_POSITION(
            "0111",
            "Throttle Position",
            "%",
            response -> OBDParser.parseBytes(response, 1)[0] * 100.0f / 255.0f),

    INTAKE_AIR_TEMP(
            "010F",
            "Intake Air Temp",
            "°C",
            response -> (float) (OBDParser.parseBytes(response, 1)[0] - 40)),

    MAF_RATE(
            "0110",
            "MAF Air Flow Rate",
            "g/s",
            response -> {
                int[] bytes = OBDParser.parseBytes(response, 2);
                return ((bytes[0] * 256) + bytes[1]) / 100.0f;
            }),

    O2_VOLTAGE_B1S1(
            "0114",
            "O2 Sensor B1S1",
            "V",
            response -> OBDParser.parseBytes(response, 1)[0] / 200.0f),

    SHORT_FUEL_TRIM_B1(
            "0106",
            "Short Fuel Trim B1",
            "%",
            response -> (OBDParser.parseBytes(response, 1)[0] - 128) * 100.0f / 128.0f),

    LONG_FUEL_TRIM_B1(
            "0107",
            "Long Fuel Trim B1",
            "%",
            response -> (OBDParser.parseBytes(response, 1)[0] - 128) * 100.0f / 128.0f),

    TIMING_ADVANCE(
            "010E",
            "Timing Advance",
            "° BTDC",
            response -> OBDParser.parseBytes(response, 1)[0] / 2.0f - 64.0f),

    CONTROL_MODULE_VOLTAGE(
            "0142",
            "Battery Voltage",
            "V",
            response -> {
                int[] bytes = OBDParser.parseBytes(response, 2);
                return ((bytes[0] * 256) + bytes[1]) / 1000.0f;
            }),

    DTC_COUNT(
            "0101",
            "DTC Count",
            "codes",
            response -> {
                int[] bytes = OBDParser.parseBytes(response, 1);
                return (float) (bytes[0] & 0x7F); // lower 7 bits
            }),

    READ_DTC(
            "03",
            "Read DTCs",
            "",
            response -> 0f);  // raw string parsed separately

    // ─────────────────────────────────────────────────────────
    public interface Parser {
        float parse(String rawResponse);
    }

    private final String  pid;
    private final String  label;
    private final String  unit;
    private final Parser  parser;

    OBDCommand(String pid, String label, String unit, Parser parser) {
        this.pid    = pid;
        this.label  = label;
        this.unit   = unit;
        this.parser = parser;
    }

    public String getPid()   { return pid; }
    public String getLabel() { return label; }
    public String getUnit()  { return unit; }

    /** Build the full AT command string to send over Bluetooth. */
    public String getCommand() { return pid + "\r"; }

    /** Parse raw ELM327 hex response → float value. */
    public float parseResponse(String rawResponse) {
        try {
            return parser.parse(rawResponse);
        } catch (Exception e) {
            return Float.NaN;
        }
    }

    /** Human-readable string with value + unit. */
    public String format(float value) {
        if (Float.isNaN(value)) return "—";
        if (unit.isEmpty()) return String.valueOf((int) value);
        return String.format("%.1f %s", value, unit);
    }
}
