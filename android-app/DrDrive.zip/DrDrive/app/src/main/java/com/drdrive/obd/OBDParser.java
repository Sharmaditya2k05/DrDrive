package com.drdrive.obd;

import java.util.ArrayList;
import java.util.List;

/**
 * OBDParser — converts raw ELM327 hex strings into usable values.
 *
 * ELM327 sends responses like:
 *   "41 0C 1A F8" for Mode 01, PID 0C (RPM)
 *   "43 01 33 00 00 00 00" for DTC codes
 *   "NO DATA" when the ECU doesn't support the PID
 *   "?" when the command is unrecognised
 */
public class OBDParser {

    /** Sentinel returned when ECU has no data for a PID. */
    public static final float NO_DATA = Float.NaN;

    // ── Core hex parser ──────────────────────────────────────

    /**
     * Strip the mode/PID echo bytes from a response and return
     * the data bytes as an int array.
     *
     * Example: "41 0C 1A F8" → strips "41 0C" → [0x1A, 0xF8]
     *
     * @param raw        full response string from ELM327
     * @param dataBytes  number of data bytes expected
     */
    public static int[] parseBytes(String raw, int dataBytes) {
        String cleaned = cleanResponse(raw);
        String[] tokens = cleaned.split("\\s+");

        // Mode 01 response starts with "41", mode 09 with "49" etc.
        // Data starts at index 2 (after mode echo + PID echo).
        int start = 2;
        if (tokens.length < start + dataBytes) {
            throw new IllegalArgumentException("Short response: " + raw);
        }

        int[] result = new int[dataBytes];
        for (int i = 0; i < dataBytes; i++) {
            result[i] = Integer.parseInt(tokens[start + i], 16);
        }
        return result;
    }

    /**
     * Parse DTC fault codes from a mode 03 response.
     * Returns a list of codes like ["P0301", "P0420"].
     */
    public static List<String> parseDTCs(String raw) {
        List<String> codes = new ArrayList<>();
        if (isNoData(raw)) return codes;

        String cleaned = cleanResponse(raw);
        // Remove "43" prefix if present
        cleaned = cleaned.replaceFirst("^43\\s*", "").trim();
        String[] tokens = cleaned.split("\\s+");

        // DTCs come in pairs of bytes
        for (int i = 0; i + 1 < tokens.length; i += 2) {
            int byte1 = Integer.parseInt(tokens[i],     16);
            int byte2 = Integer.parseInt(tokens[i + 1], 16);

            if (byte1 == 0 && byte2 == 0) continue; // padding

            char category;
            switch ((byte1 >> 6) & 0x03) {
                case 0:  category = 'P'; break; // Powertrain
                case 1:  category = 'C'; break; // Chassis
                case 2:  category = 'B'; break; // Body
                default: category = 'U'; break; // Network
            }

            int code = ((byte1 & 0x3F) << 8) | byte2;
            codes.add(String.format("%c%04X", category, code));
        }
        return codes;
    }

    /** True when ELM327 says the ECU has no data for the PID. */
    public static boolean isNoData(String raw) {
        if (raw == null) return true;
        String upper = raw.trim().toUpperCase();
        return upper.contains("NO DATA")
                || upper.contains("NODATA")
                || upper.equals("?")
                || upper.contains("ERROR")
                || upper.contains("UNABLE TO CONNECT")
                || upper.isEmpty();
    }

    /** Remove CR, LF, extra spaces; upper-case for consistent parsing. */
    public static String cleanResponse(String raw) {
        if (raw == null) return "";
        return raw.trim()
                .replace("\r", " ")
                .replace("\n", " ")
                .replaceAll("\\s+", " ")
                .toUpperCase();
    }

    // ── Convenience parsers used by OBDCommand lambdas ───────

    /** Parse a single-byte percentage: (byte / 255) * 100 */
    public static float parseSingleBytePercent(String raw) {
        return parseBytes(raw, 1)[0] * 100.0f / 255.0f;
    }

    /** Parse a single-byte temperature with -40 offset. */
    public static float parseTempCelsius(String raw) {
        return parseBytes(raw, 1)[0] - 40.0f;
    }
}
