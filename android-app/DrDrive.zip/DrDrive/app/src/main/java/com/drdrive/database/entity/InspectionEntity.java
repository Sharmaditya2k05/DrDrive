package com.drdrive.database.entity;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * InspectionEntity — Room table that caches completed inspection reports locally.
 * Full InspectionReport JSON is stored as a single text column for simplicity;
 * parsed back to model class via Gson in the Repository.
 */
@Entity(tableName = "inspections")
public class InspectionEntity {

    @PrimaryKey
    @ColumnInfo(name = "report_id")
    public String reportId;

    @ColumnInfo(name = "created_at")
    public long createdAt;

    @ColumnInfo(name = "car_display_name")
    public String carDisplayName;   // e.g. "2019 Maruti Swift"

    @ColumnInfo(name = "health_score")
    public int healthScore;

    @ColumnInfo(name = "market_value")
    public long marketValue;

    @ColumnInfo(name = "damage_count")
    public int damageCount;

    @ColumnInfo(name = "status")
    public String status;           // "complete" | "pending" | "error"

    @ColumnInfo(name = "report_json")
    public String reportJson;       // full JSON blob for offline access

    @ColumnInfo(name = "synced")
    public boolean synced;          // true once uploaded to backend
}
