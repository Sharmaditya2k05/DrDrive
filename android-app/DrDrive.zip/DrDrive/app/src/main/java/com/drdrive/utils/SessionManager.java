package com.drdrive.utils;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import java.io.IOException;
import java.security.GeneralSecurityException;

/**
 * SessionManager — stores JWT token + user info in EncryptedSharedPreferences.
 * Falls back to regular SharedPreferences on older devices if encryption fails.
 */
public class SessionManager {

    private static final String PREF_FILE     = "dr_drive_session";
    private static final String KEY_TOKEN     = "auth_token";
    private static final String KEY_USER_NAME = "user_name";
    private static final String KEY_USER_EMAIL= "user_email";
    private static final String KEY_LOGGED_IN = "is_logged_in";

    private final SharedPreferences prefs;

    public SessionManager(Context context) {
        SharedPreferences p;
        try {
            MasterKey masterKey = new MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();
            p = EncryptedSharedPreferences.create(
                    context,
                    PREF_FILE,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);
        } catch (GeneralSecurityException | IOException e) {
            // Fallback — plain prefs (dev/emulator)
            p = context.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE);
        }
        this.prefs = p;
    }

    public void saveSession(String token, String name, String email) {
        prefs.edit()
                .putString(KEY_TOKEN,      token)
                .putString(KEY_USER_NAME,  name)
                .putString(KEY_USER_EMAIL, email)
                .putBoolean(KEY_LOGGED_IN, true)
                .apply();
    }

    public boolean isLoggedIn()   { return prefs.getBoolean(KEY_LOGGED_IN, false); }
    public String  getToken()     { return prefs.getString(KEY_TOKEN,      ""); }
    public String  getUserName()  { return prefs.getString(KEY_USER_NAME,  ""); }
    public String  getUserEmail() { return prefs.getString(KEY_USER_EMAIL, ""); }

    public void clearSession() {
        prefs.edit().clear().apply();
    }
}
