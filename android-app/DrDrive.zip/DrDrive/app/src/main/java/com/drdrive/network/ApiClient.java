package com.drdrive.network;

import com.drdrive.BuildConfig;
import com.drdrive.utils.Constants;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * ApiClient — thread-safe Retrofit singleton.
 * Uses OkHttp with JWT injection and logging.
 */
public class ApiClient {

    private static volatile Retrofit instance;
    private static String authToken = "";

    private ApiClient() {}

    public static void setToken(String token) {
        authToken = token;
        // Invalidate singleton so next call rebuilds with new token
        instance = null;
    }

    public static Retrofit getInstance() {
        if (instance == null) {
            synchronized (ApiClient.class) {
                if (instance == null) {
                    instance = buildRetrofit();
                }
            }
        }
        return instance;
    }

    public static ApiService getService() {
        return getInstance().create(ApiService.class);
    }

    private static Retrofit buildRetrofit() {
        // Logging — verbose in debug, silent in release
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(BuildConfig.DEBUG
                ? HttpLoggingInterceptor.Level.BODY
                : HttpLoggingInterceptor.Level.NONE);

        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(new AuthInterceptor(authToken))
                .addInterceptor(logging)
                .connectTimeout(Constants.CONNECT_TIMEOUT_SEC, TimeUnit.SECONDS)
                .readTimeout(Constants.READ_TIMEOUT_SEC,    TimeUnit.SECONDS)
                .writeTimeout(Constants.WRITE_TIMEOUT_SEC,  TimeUnit.SECONDS)
                .build();

        return new Retrofit.Builder()
                .baseUrl(BuildConfig.BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }
}
