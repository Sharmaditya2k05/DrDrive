package com.drdrive;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

/**
 * DrDriveApp — Application singleton.
 * Initialises global state: notification channels, Glide, etc.
 */
public class DrDriveApp extends Application {

    public static final String CHANNEL_UPLOAD  = "ch_upload";
    public static final String CHANNEL_OBD     = "ch_obd";

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannels();
    }

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);

            NotificationChannel upload = new NotificationChannel(
                    CHANNEL_UPLOAD,
                    "Data Upload",
                    NotificationManager.IMPORTANCE_LOW);
            upload.setDescription("Shows upload progress for inspection data");

            NotificationChannel obd = new NotificationChannel(
                    CHANNEL_OBD,
                    "OBD Connection",
                    NotificationManager.IMPORTANCE_LOW);
            obd.setDescription("OBD-II Bluetooth connection status");

            nm.createNotificationChannel(upload);
            nm.createNotificationChannel(obd);
        }
    }
}
