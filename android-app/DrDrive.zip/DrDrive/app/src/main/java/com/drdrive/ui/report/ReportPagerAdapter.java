package com.drdrive.ui.report;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

/**
 * Drives the three-tab report ViewPager2.
 */
public class ReportPagerAdapter extends FragmentStateAdapter {

    public ReportPagerAdapter(@NonNull FragmentActivity activity) {
        super(activity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0: return new HealthFragment();
            case 1: return new DamageFragment();
            case 2: return new ValuationFragment();
            default: return new HealthFragment();
        }
    }

    @Override
    public int getItemCount() { return 3; }
}
