package com.drdrive.repository;

import android.content.Context;

import com.drdrive.model.OBDReading;
import com.drdrive.obd.BluetoothManager;
import com.drdrive.obd.ELM327Manager;
import com.drdrive.obd.OBDDataCollector;

import java.util.ArrayList;
import java.util.List;

/**
 * OBDRepository — bridges BluetoothManager + OBDDataCollector to the ViewModel.
 * Maintains the list of all readings collected during a session.
 */
public class OBDRepository {

    public interface ScanCallback {
        void onDevicesFound(List<String> deviceNames, List<String> deviceMacs);
        void onConnected();
        void onReading(OBDReading reading);
        void onDTCs(List<String> codes);
        void onError(String message);
    }

    private final BluetoothManager bluetoothManager;
    private OBDDataCollector        collector;
    private final List<OBDReading>  sessionReadings = new ArrayList<>();

    public OBDRepository(Context context) {
        this.bluetoothManager = new BluetoothManager(context);
    }

    // ── Discovery ────────────────────────────────────────────

    public void discoverDevices(ScanCallback callback) {
        if (!bluetoothManager.isBluetoothEnabled()) {
            callback.onError("Bluetooth is not enabled");
            return;
        }

        bluetoothManager.discoverOBDDevices(new BluetoothManager.DiscoveryCallback() {
            @Override
            public void onDevicesFound(List<android.bluetooth.BluetoothDevice> devices) {
                List<String> names = new ArrayList<>();
                List<String> macs  = new ArrayList<>();
                for (android.bluetooth.BluetoothDevice d : devices) {
                    names.add(d.getName() != null ? d.getName() : "Unknown");
                    macs.add(d.getAddress());
                }
                callback.onDevicesFound(names, macs);
            }

            @Override
            public void onError(String message) {
                callback.onError(message);
            }
        });
    }

    // ── Connection ───────────────────────────────────────────

    public void connect(String macAddress, ScanCallback callback) {
        bluetoothManager.connectToDevice(macAddress, new BluetoothManager.ConnectionCallback() {
            @Override
            public void onConnected(ELM327Manager elm327) {
                callback.onConnected();
                startCollecting(elm327, callback);
            }

            @Override
            public void onError(String message) {
                callback.onError(message);
            }
        });
    }

    private void startCollecting(ELM327Manager elm327, ScanCallback callback) {
        collector = new OBDDataCollector(elm327, new OBDDataCollector.ReadingCallback() {
            @Override
            public void onReading(OBDReading reading) {
                sessionReadings.add(reading);
                callback.onReading(reading);
            }

            @Override
            public void onDTCs(List<String> dtcCodes) {
                callback.onDTCs(dtcCodes);
            }

            @Override
            public void onError(String message) {
                callback.onError(message);
            }
        });
        collector.start();
    }

    // ── Session data ─────────────────────────────────────────

    public List<OBDReading> getSessionReadings() {
        return new ArrayList<>(sessionReadings);
    }

    /** Returns the last reading of the session (most recent snapshot). */
    public OBDReading getLatestReading() {
        if (sessionReadings.isEmpty()) return null;
        return sessionReadings.get(sessionReadings.size() - 1);
    }

    public void stopCollection() {
        if (collector != null) collector.stop();
    }

    public void disconnect() {
        stopCollection();
        bluetoothManager.disconnect();
        sessionReadings.clear();
    }
}
