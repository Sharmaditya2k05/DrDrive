package com.drdrive.viewmodel;

import android.app.Application;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.util.ArrayList;
import java.util.List;

/**
 * CameraViewModel — tracks the 6 captured photo URIs.
 * Survives screen rotation so photos aren't lost.
 */
public class CameraViewModel extends AndroidViewModel {

    private final MutableLiveData<List<Uri>> capturedPhotos = new MutableLiveData<>(new ArrayList<>());

    public CameraViewModel(@NonNull Application application) {
        super(application);
    }

    public void addPhoto(int angleIndex, Uri photoUri) {
        List<Uri> current = capturedPhotos.getValue();
        if (current == null) current = new ArrayList<>();
        // Pad list if needed
        while (current.size() <= angleIndex) current.add(null);
        current.set(angleIndex, photoUri);
        capturedPhotos.setValue(current);
    }

    public void removeLastPhoto() {
        List<Uri> current = capturedPhotos.getValue();
        if (current != null && !current.isEmpty()) {
            current.remove(current.size() - 1);
            capturedPhotos.setValue(current);
        }
    }

    /** Returns file paths as strings for Intent bundling. */
    public ArrayList<String> getPhotoPathList() {
        ArrayList<String> paths = new ArrayList<>();
        List<Uri> photos = capturedPhotos.getValue();
        if (photos != null) {
            for (Uri uri : photos) {
                if (uri != null) paths.add(uri.toString());
            }
        }
        return paths;
    }

    public LiveData<List<Uri>> getCapturedPhotos() { return capturedPhotos; }
}
