package com.drdrive.ui.report;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.drdrive.databinding.FragmentHealthBinding;
import com.drdrive.viewmodel.ReportViewModel;

/**
 * HealthFragment — Tab 1.
 * Shows overall health score gauge + component breakdown.
 * Full gauge + chart code added in Step 6 (Report UI).
 */
public class HealthFragment extends Fragment {

    private FragmentHealthBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentHealthBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ReportViewModel vm = new ViewModelProvider(requireActivity()).get(ReportViewModel.class);

        vm.getHealthScore().observe(getViewLifecycleOwner(), score -> {
            if (score != null) {
                binding.tvHealthScore.setText(String.valueOf(score.getOverallScore()));
                binding.tvEngineHealth.setText(score.getEngineHealth() + "%");
                binding.tvTransmissionHealth.setText(score.getTransmissionHealth() + "%");
                binding.tvBatteryHealth.setText(score.getBatteryHealth() + "%");
                binding.tvEmissionHealth.setText(score.getEmissionHealth() + "%");
            }
        });
    }

    @Override
    public void onDestroyView() { super.onDestroyView(); binding = null; }
}
