package com.drdrive.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.drdrive.model.OBDReading;

import java.util.List;

/**
 * OBDViewModel — exposes BT scan state + live OBD readings to OBDScanActivity.
 * Repository + ELM327 wiring done in Step 3.
 */
public class OBDViewModel extends AndroidViewModel {

    public enum ConnectionState { IDLE, SCANNING, CONNECTED, COMPLETE, ERROR }

    private final MutableLiveData<ConnectionState> connectionState   = new MutableLiveData<>(ConnectionState.IDLE);
    private final MutableLiveData<List<String>>    discoveredDevices = new MutableLiveData<>();
    private final MutableLiveData<String>          selectedDevice    = new MutableLiveData<>();
    private final MutableLiveData<OBDReading>      liveReadings      = new MutableLiveData<>();

    private String obdSessionId;

    public OBDViewModel(@NonNull Application application) {
        super(application);
    }

    public void startDeviceDiscovery() {
        connectionState.setValue(ConnectionState.SCANNING);
        // Step 3: BluetoothManager.startDiscovery(callback)
    }

    public void connectToDevice(String deviceAddress) {
        selectedDevice.setValue(deviceAddress);
        connectionState.setValue(ConnectionState.CONNECTED);
        // Step 3: ELM327Manager.connect(deviceAddress)
    }

    public void setConnectionState(ConnectionState state) {
        connectionState.setValue(state);
    }

    public void postLiveReading(OBDReading reading) {
        liveReadings.postValue(reading);
    }

    public void setObdSessionId(String id)    { this.obdSessionId = id; }
    public String getObdSessionId()           { return obdSessionId; }

    public LiveData<ConnectionState> getConnectionState()   { return connectionState; }
    public LiveData<List<String>>    getDiscoveredDevices() { return discoveredDevices; }
    public LiveData<String>          getSelectedDevice()    { return selectedDevice; }
    public LiveData<OBDReading>      getLiveReadings()      { return liveReadings; }
}
