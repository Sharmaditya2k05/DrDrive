package com.drdrive.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

/** Full inspection report returned from backend — stored in Room DB. */
public class InspectionReport {

    @SerializedName("report_id")     private String      reportId;
    @SerializedName("created_at")    private long        createdAt;
    @SerializedName("car_metadata")  private CarMetadata carMetadata;
    @SerializedName("health_score")  private HealthScore healthScore;
    @SerializedName("damages")       private List<DamageResult> damages;
    @SerializedName("valuation")     private Valuation   valuation;
    @SerializedName("status")        private String      status;  // pending | complete | error

    public String           getReportId()    { return reportId; }
    public long             getCreatedAt()   { return createdAt; }
    public CarMetadata      getCarMetadata() { return carMetadata; }
    public HealthScore      getHealthScore() { return healthScore; }
    public List<DamageResult> getDamages()   { return damages; }
    public Valuation        getValuation()   { return valuation; }
    public String           getStatus()      { return status; }

    public void setReportId(String v)               { reportId = v; }
    public void setCreatedAt(long v)                { createdAt = v; }
    public void setCarMetadata(CarMetadata v)       { carMetadata = v; }
    public void setHealthScore(HealthScore v)       { healthScore = v; }
    public void setDamages(List<DamageResult> v)    { damages = v; }
    public void setValuation(Valuation v)           { valuation = v; }
    public void setStatus(String v)                 { status = v; }
}
