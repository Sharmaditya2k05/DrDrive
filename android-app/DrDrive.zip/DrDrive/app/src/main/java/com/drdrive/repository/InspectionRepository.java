package com.drdrive.repository;

import android.content.Context;
import android.net.Uri;
import android.util.Log;

import androidx.lifecycle.LiveData;

import com.drdrive.database.AppDatabase;
import com.drdrive.database.InspectionDao;
import com.drdrive.database.entity.InspectionEntity;
import com.drdrive.model.InspectionReport;
import com.drdrive.model.OBDReading;
import com.drdrive.network.ApiClient;
import com.drdrive.network.ApiService;
import com.drdrive.utils.ImageUtils;
import com.google.gson.Gson;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * InspectionRepository — orchestrates upload, polling, and local caching
 * of inspection reports.
 *
 * Called by ReportViewModel; never accessed directly from UI.
 */
public class InspectionRepository {

    private static final String TAG = "InspectionRepo";

    public interface AnalysisCallback {
        void onUploading();
        void onAnalysing();
        void onComplete(InspectionReport report);
        void onError(String message);
    }

    private final Context         context;
    private final InspectionDao   dao;
    private final ApiService      api;
    private final Gson            gson = new Gson();
    private final ExecutorService executor = Executors.newCachedThreadPool();

    public InspectionRepository(Context context) {
        this.context = context;
        this.dao     = AppDatabase.getInstance(context).inspectionDao();
        this.api     = ApiClient.getService();
    }

    // ── Start analysis ───────────────────────────────────────

    /**
     * Upload OBD data + images, then poll until the backend completes analysis.
     */
    public void startAnalysis(
            OBDReading  obdReading,
            List<String> photoPaths,
            String       carMetadataJson,
            AnalysisCallback callback) {

        executor.execute(() -> {
            callback.onUploading();

            try {
                // Build multipart fields
                Map<String, RequestBody> fields = new HashMap<>();
                fields.put("obd_data",      toBody(gson.toJson(obdReading)));
                fields.put("car_metadata",  toBody(carMetadataJson));

                // Build image parts — compress before upload
                List<MultipartBody.Part> imageParts = new ArrayList<>();
                for (int i = 0; i < photoPaths.size(); i++) {
                    File compressed = ImageUtils.compressImage(
                            context, Uri.parse(photoPaths.get(i)), i);
                    if (compressed != null) {
                        RequestBody body = RequestBody.create(
                                MediaType.parse("image/jpeg"), compressed);
                        imageParts.add(MultipartBody.Part.createFormData(
                                "images", "angle_" + i + ".jpg", body));
                    }
                }

                // Upload
                Response<ApiService.CreateInspectionResponse> uploadResp =
                        api.createInspection(fields, imageParts).execute();

                if (!uploadResp.isSuccessful() || uploadResp.body() == null) {
                    callback.onError("Upload failed: " + uploadResp.code());
                    return;
                }

                String reportId = uploadResp.body().report_id;
                Log.d(TAG, "Upload OK, report_id=" + reportId);

                // Poll for completion
                callback.onAnalysing();
                InspectionReport report = pollUntilComplete(reportId);

                if (report != null) {
                    cacheLocally(report);
                    callback.onComplete(report);
                } else {
                    callback.onError("Analysis timed out. Please try again.");
                }

            } catch (Exception e) {
                Log.e(TAG, "Analysis error", e);
                callback.onError("Error: " + e.getMessage());
            }
        });
    }

    // ── Polling ──────────────────────────────────────────────

    private static final int  POLL_MAX_TRIES    = 30;
    private static final long POLL_INTERVAL_MS  = 3000;

    private InspectionReport pollUntilComplete(String reportId) throws Exception {
        for (int i = 0; i < POLL_MAX_TRIES; i++) {
            Thread.sleep(POLL_INTERVAL_MS);

            Response<InspectionReport> resp = api.getReport(reportId).execute();
            if (resp.isSuccessful() && resp.body() != null) {
                InspectionReport report = resp.body();
                if ("complete".equals(report.getStatus())) {
                    Log.d(TAG, "Analysis complete after " + (i + 1) + " polls");
                    return report;
                }
                Log.d(TAG, "Poll " + (i + 1) + ": status=" + report.getStatus());
            }
        }
        return null; // timed out
    }

    // ── Local cache ──────────────────────────────────────────

    private void cacheLocally(InspectionReport report) {
        executor.execute(() -> {
            InspectionEntity entity = new InspectionEntity();
            entity.reportId      = report.getReportId();
            entity.createdAt     = report.getCreatedAt();
            entity.healthScore   = report.getHealthScore() != null
                    ? report.getHealthScore().getOverallScore() : 0;
            entity.marketValue   = report.getValuation() != null
                    ? report.getValuation().getFairMarketValue() : 0;
            entity.damageCount   = report.getDamages() != null
                    ? report.getDamages().size() : 0;
            entity.carDisplayName = report.getCarMetadata() != null
                    ? report.getCarMetadata().getDisplayName() : "Unknown Car";
            entity.status        = "complete";
            entity.reportJson    = gson.toJson(report);
            entity.synced        = true;
            dao.insert(entity);
            Log.d(TAG, "Cached report " + entity.reportId);
        });
    }

    // ── Queries (return LiveData for UI) ─────────────────────

    public LiveData<List<InspectionEntity>> getAllInspections() {
        return dao.getAllInspections();
    }

    public LiveData<List<InspectionEntity>> getRecentInspections() {
        return dao.getRecentInspections();
    }

    public InspectionReport getReportById(String reportId) {
        InspectionEntity entity = dao.getById(reportId);
        if (entity == null || entity.reportJson == null) return null;
        return gson.fromJson(entity.reportJson, InspectionReport.class);
    }

    // ── Helpers ──────────────────────────────────────────────

    private RequestBody toBody(String value) {
        return RequestBody.create(MediaType.parse("text/plain"), value);
    }
}
