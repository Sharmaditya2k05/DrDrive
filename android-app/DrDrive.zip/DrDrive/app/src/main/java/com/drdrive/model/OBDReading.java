package com.drdrive.model;

import com.google.gson.annotations.SerializedName;

/**
 * One snapshot of all OBD-II sensor values collected from ELM327.
 * Sent to backend as part of the inspection payload.
 */
public class OBDReading {

    @SerializedName("timestamp")        private long    timestamp;
    @SerializedName("rpm")              private int     rpm;
    @SerializedName("speed")            private int     speed;
    @SerializedName("coolant_temp")     private int     coolantTemp;
    @SerializedName("intake_air_temp")  private int     intakeAirTemp;
    @SerializedName("engine_load")      private float   engineLoad;
    @SerializedName("throttle_pos")     private float   throttlePosition;
    @SerializedName("fuel_trim_st")     private float   shortTermFuelTrim;
    @SerializedName("fuel_trim_lt")     private float   longTermFuelTrim;
    @SerializedName("battery_voltage")  private float   batteryVoltage;
    @SerializedName("o2_voltage")       private float   o2Voltage;
    @SerializedName("maf")              private float   maf;
    @SerializedName("timing_advance")   private float   timingAdvance;
    @SerializedName("dtc_codes")        private String  dtcCodes;      // comma-separated e.g. "P0301,P0420"
    @SerializedName("mil_on")           private boolean milOn;
    @SerializedName("dtc_count")        private int     dtcCount;

    // ── Getters ──────────────────────────────────────────────
    public long    getTimestamp()        { return timestamp; }
    public int     getRpm()              { return rpm; }
    public int     getSpeed()            { return speed; }
    public int     getCoolantTemp()      { return coolantTemp; }
    public int     getIntakeAirTemp()    { return intakeAirTemp; }
    public float   getEngineLoad()       { return engineLoad; }
    public float   getThrottlePosition() { return throttlePosition; }
    public float   getShortTermFuelTrim(){ return shortTermFuelTrim; }
    public float   getLongTermFuelTrim() { return longTermFuelTrim; }
    public float   getBatteryVoltage()   { return batteryVoltage; }
    public float   getO2Voltage()        { return o2Voltage; }
    public float   getMaf()              { return maf; }
    public float   getTimingAdvance()    { return timingAdvance; }
    public String  getDtcCodes()         { return dtcCodes; }
    public boolean isMilOn()             { return milOn; }
    public int     getDtcCount()         { return dtcCount; }

    // ── Setters ──────────────────────────────────────────────
    public void setTimestamp(long v)         { this.timestamp = v; }
    public void setRpm(int v)                { this.rpm = v; }
    public void setSpeed(int v)              { this.speed = v; }
    public void setCoolantTemp(int v)        { this.coolantTemp = v; }
    public void setIntakeAirTemp(int v)      { this.intakeAirTemp = v; }
    public void setEngineLoad(float v)       { this.engineLoad = v; }
    public void setThrottlePosition(float v) { this.throttlePosition = v; }
    public void setShortTermFuelTrim(float v){ this.shortTermFuelTrim = v; }
    public void setLongTermFuelTrim(float v) { this.longTermFuelTrim = v; }
    public void setBatteryVoltage(float v)   { this.batteryVoltage = v; }
    public void setO2Voltage(float v)        { this.o2Voltage = v; }
    public void setMaf(float v)              { this.maf = v; }
    public void setTimingAdvance(float v)    { this.timingAdvance = v; }
    public void setDtcCodes(String v)        { this.dtcCodes = v; }
    public void setMilOn(boolean v)          { this.milOn = v; }
    public void setDtcCount(int v)           { this.dtcCount = v; }
}
