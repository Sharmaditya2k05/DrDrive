package com.drdrive.obd;

import android.bluetooth.BluetoothSocket;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

/**
 * ELM327Manager — manages the low-level conversation with an ELM327 adapter.
 *
 * Lifecycle:
 *   1. Receive a connected BluetoothSocket from BluetoothManager
 *   2. Call initialise() — sends AT init sequence
 *   3. Call read(OBDCommand) in a loop for live data
 *   4. Call readDTCs() once for fault codes
 *   5. Call close() when done
 */
public class ELM327Manager {

    private static final String TAG            = "ELM327";
    private static final int    READ_TIMEOUT   = 2000; // ms
    private static final char   PROMPT         = '>';  // ELM327 ready prompt

    private final BluetoothSocket socket;
    private final InputStream     inputStream;
    private final OutputStream    outputStream;

    public ELM327Manager(BluetoothSocket socket) throws IOException {
        this.socket       = socket;
        this.inputStream  = socket.getInputStream();
        this.outputStream = socket.getOutputStream();
    }

    // ── Initialisation ───────────────────────────────────────

    /**
     * Send the standard ELM327 initialisation sequence.
     * Must be called once immediately after the socket connects.
     *
     * @throws IOException if any command fails
     */
    public void initialise() throws IOException {
        sendCommand("ATZ");          // Reset
        sleep(1000);                 // Wait for reset to complete
        readRaw();                   // Flush welcome message

        sendAndExpect("ATE0", "OK"); // Echo off
        sendAndExpect("ATL0", "OK"); // Line feeds off
        sendAndExpect("ATH0", "OK"); // Headers off
        sendAndExpect("ATSP0","OK"); // Auto-select protocol
        sendAndExpect("ATST32","OK");// Set timeout ~200ms per byte
        Log.d(TAG, "ELM327 initialised");
    }

    // ── PID reading ──────────────────────────────────────────

    /**
     * Send a single OBD PID command and return the parsed float value.
     * Returns Float.NaN if the ECU has no data for this PID.
     */
    public float read(OBDCommand cmd) throws IOException {
        String raw = sendAndRead(cmd.getCommand());
        if (OBDParser.isNoData(raw)) return Float.NaN;
        return cmd.parseResponse(raw);
    }

    /**
     * Read all current Diagnostic Trouble Codes.
     * Returns an empty list if no faults are stored.
     */
    public List<String> readDTCs() throws IOException {
        String raw = sendAndRead("03\r");
        return OBDParser.parseDTCs(raw);
    }

    // ── Low-level I/O ────────────────────────────────────────

    private String sendAndRead(String command) throws IOException {
        sendCommand(command);
        return readRaw();
    }

    private void sendAndExpect(String command, String expected) throws IOException {
        String response = sendAndRead(command + "\r");
        if (!response.toUpperCase().contains(expected.toUpperCase())) {
            Log.w(TAG, "Unexpected response to " + command + ": " + response);
        }
    }

    private void sendCommand(String command) throws IOException {
        String cmd = command.endsWith("\r") ? command : command + "\r";
        outputStream.write(cmd.getBytes());
        outputStream.flush();
        Log.v(TAG, ">> " + command.trim());
    }

    /**
     * Read bytes from the adapter until the '>' prompt or timeout.
     */
    private String readRaw() throws IOException {
        StringBuilder sb      = new StringBuilder();
        long          started = System.currentTimeMillis();

        while (System.currentTimeMillis() - started < READ_TIMEOUT) {
            if (inputStream.available() > 0) {
                int b = inputStream.read();
                if (b == -1) break;
                char c = (char) b;
                if (c == PROMPT) break;   // ELM327 is ready for next command
                if (c != '\r') sb.append(c);
            } else {
                sleep(10);
            }
        }

        String result = sb.toString().trim();
        Log.v(TAG, "<< " + result);
        return result;
    }

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    // ── Lifecycle ────────────────────────────────────────────

    public void close() {
        try { if (socket != null) socket.close(); }
        catch (IOException e) { Log.e(TAG, "Error closing socket", e); }
    }

    public boolean isConnected() {
        return socket != null && socket.isConnected();
    }
}
