package com.drdrive.utils;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * PermissionHelper — wraps ActivityResult API for runtime permissions.
 * Must be constructed in Activity.onCreate() before any user interaction.
 */
public class PermissionHelper {

    public interface PermissionCallback {
        void onResult(boolean allGranted);
    }

    private final AppCompatActivity activity;
    private PermissionCallback pendingCallback;

    private final ActivityResultLauncher<String[]> launcher;

    public PermissionHelper(AppCompatActivity activity) {
        this.activity = activity;
        launcher = activity.registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                this::handleResults);
    }

    private void handleResults(Map<String, Boolean> results) {
        if (pendingCallback != null) {
            boolean allGranted = true;
            for (Boolean granted : results.values()) {
                if (!granted) { allGranted = false; break; }
            }
            pendingCallback.onResult(allGranted);
            pendingCallback = null;
        }
    }

    /** Request all permissions needed for Bluetooth OBD scanning. */
    public void requestBluetoothPermissions(PermissionCallback callback) {
        List<String> needed = new ArrayList<>();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            addIfMissing(needed, Manifest.permission.BLUETOOTH_CONNECT);
            addIfMissing(needed, Manifest.permission.BLUETOOTH_SCAN);
        } else {
            addIfMissing(needed, Manifest.permission.BLUETOOTH);
            addIfMissing(needed, Manifest.permission.BLUETOOTH_ADMIN);
            addIfMissing(needed, Manifest.permission.ACCESS_FINE_LOCATION);
        }

        if (needed.isEmpty()) {
            callback.onResult(true);
        } else {
            pendingCallback = callback;
            launcher.launch(needed.toArray(new String[0]));
        }
    }

    /** Request camera permission. */
    public void requestCameraPermission(PermissionCallback callback) {
        List<String> needed = new ArrayList<>();
        addIfMissing(needed, Manifest.permission.CAMERA);

        if (needed.isEmpty()) {
            callback.onResult(true);
        } else {
            pendingCallback = callback;
            launcher.launch(needed.toArray(new String[0]));
        }
    }

    /** Request notification permission (Android 13+). */
    public void requestNotificationPermission(PermissionCallback callback) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            List<String> needed = new ArrayList<>();
            addIfMissing(needed, Manifest.permission.POST_NOTIFICATIONS);
            if (needed.isEmpty()) { callback.onResult(true); return; }
            pendingCallback = callback;
            launcher.launch(needed.toArray(new String[0]));
        } else {
            callback.onResult(true);
        }
    }

    private void addIfMissing(List<String> list, String permission) {
        if (ContextCompat.checkSelfPermission(activity, permission)
                != PackageManager.PERMISSION_GRANTED) {
            list.add(permission);
        }
    }
}
