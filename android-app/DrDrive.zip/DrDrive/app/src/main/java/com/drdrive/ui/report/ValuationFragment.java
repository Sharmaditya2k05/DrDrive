package com.drdrive.ui.report;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.drdrive.databinding.FragmentValuationBinding;
import com.drdrive.viewmodel.ReportViewModel;

import java.text.NumberFormat;
import java.util.Locale;

/**
 * ValuationFragment — Tab 3.
 * Shows repair cost breakdown + fair market valuation in INR.
 */
public class ValuationFragment extends Fragment {

    private FragmentValuationBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentValuationBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ReportViewModel vm = new ViewModelProvider(requireActivity()).get(ReportViewModel.class);
        NumberFormat inr = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));

        vm.getValuation().observe(getViewLifecycleOwner(), val -> {
            if (val != null) {
                binding.tvMarketValue.setText(inr.format(val.getFairMarketValue()));
                binding.tvRepairCostMin.setText(inr.format(val.getRepairCostMin()));
                binding.tvRepairCostMax.setText(inr.format(val.getRepairCostMax()));
                binding.tvAdjustedValue.setText(inr.format(val.getAdjustedValue()));
                binding.tvFraudFlag.setVisibility(
                        val.isFraudSuspected() ? View.VISIBLE : View.GONE);
            }
        });
    }

    @Override
    public void onDestroyView() { super.onDestroyView(); binding = null; }
}
