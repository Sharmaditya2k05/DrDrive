package com.drdrive.model;

import com.google.gson.annotations.SerializedName;

/** Overall + per-component health percentages returned by backend. */
public class HealthScore {

    @SerializedName("overall_score")       private int overallScore;
    @SerializedName("engine_health")       private int engineHealth;
    @SerializedName("transmission_health") private int transmissionHealth;
    @SerializedName("battery_health")      private int batteryHealth;
    @SerializedName("emission_health")     private int emissionHealth;
    @SerializedName("grade")               private String grade;   // A / B / C / D
    @SerializedName("summary")             private String summary;

    public int    getOverallScore()        { return overallScore; }
    public int    getEngineHealth()        { return engineHealth; }
    public int    getTransmissionHealth()  { return transmissionHealth; }
    public int    getBatteryHealth()       { return batteryHealth; }
    public int    getEmissionHealth()      { return emissionHealth; }
    public String getGrade()               { return grade; }
    public String getSummary()             { return summary; }

    public void setOverallScore(int v)       { overallScore = v; }
    public void setEngineHealth(int v)       { engineHealth = v; }
    public void setTransmissionHealth(int v) { transmissionHealth = v; }
    public void setBatteryHealth(int v)      { batteryHealth = v; }
    public void setEmissionHealth(int v)     { emissionHealth = v; }
    public void setGrade(String v)           { grade = v; }
    public void setSummary(String v)         { summary = v; }
}
