package com.drdrive.ui.auth;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.drdrive.databinding.ActivityLoginBinding;
import com.drdrive.ui.MainActivity;
import com.drdrive.viewmodel.AuthViewModel;

/**
 * LoginActivity — email/password login.
 * Observes AuthViewModel for login result.
 */
public class LoginActivity extends AppCompatActivity {

    private ActivityLoginBinding binding;
    private AuthViewModel authViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        authViewModel = new ViewModelProvider(this).get(AuthViewModel.class);

        observeViewModel();
        setupClickListeners();
    }

    private void observeViewModel() {
        authViewModel.getLoginResult().observe(this, result -> {
            binding.progressBar.setVisibility(View.GONE);
            if (result.isSuccess()) {
                startActivity(new Intent(this, MainActivity.class));
                finishAffinity();
            } else {
                Toast.makeText(this, result.getError(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void setupClickListeners() {
        binding.btnLogin.setOnClickListener(v -> {
            String email    = binding.etEmail.getText().toString().trim();
            String password = binding.etPassword.getText().toString().trim();

            if (TextUtils.isEmpty(email)) {
                binding.etEmail.setError("Email required");
                return;
            }
            if (TextUtils.isEmpty(password)) {
                binding.etPassword.setError("Password required");
                return;
            }

            binding.progressBar.setVisibility(View.VISIBLE);
            authViewModel.login(email, password);
        });

        binding.tvRegister.setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class)));

        // Quick dev bypass — remove for production
        binding.tvSkip.setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class));
            finishAffinity();
        });
    }
}
