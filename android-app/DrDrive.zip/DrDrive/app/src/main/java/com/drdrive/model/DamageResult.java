package com.drdrive.model;

import com.google.gson.annotations.SerializedName;

/**
 * One detected damage item from the YOLOv8 vision model.
 * Contains bounding box coordinates for overlay rendering.
 */
public class DamageResult {

    @SerializedName("damage_id")      private String damageId;
    @SerializedName("angle_index")    private int    angleIndex;   // 0-5 matching capture order
    @SerializedName("angle_label")    private String angleLabel;   // "Front view" etc.
    @SerializedName("damage_type")    private String damageType;   // dent | scratch | crack | broken_glass
    @SerializedName("severity")       private String severity;     // minor | moderate | severe
    @SerializedName("confidence")     private float  confidence;   // 0.0 - 1.0
    @SerializedName("bbox_x")         private float  bboxX;        // normalised 0-1
    @SerializedName("bbox_y")         private float  bboxY;
    @SerializedName("bbox_w")         private float  bboxW;
    @SerializedName("bbox_h")         private float  bboxH;
    @SerializedName("repair_cost_min") private int   repairCostMin;
    @SerializedName("repair_cost_max") private int   repairCostMax;
    @SerializedName("description")    private String description;

    public String getDamageId()      { return damageId; }
    public int    getAngleIndex()    { return angleIndex; }
    public String getAngleLabel()    { return angleLabel; }
    public String getDamageType()    { return damageType; }
    public String getSeverity()      { return severity; }
    public float  getConfidence()    { return confidence; }
    public float  getBboxX()         { return bboxX; }
    public float  getBboxY()         { return bboxY; }
    public float  getBboxW()         { return bboxW; }
    public float  getBboxH()         { return bboxH; }
    public int    getRepairCostMin() { return repairCostMin; }
    public int    getRepairCostMax() { return repairCostMax; }
    public String getDescription()   { return description; }
}
