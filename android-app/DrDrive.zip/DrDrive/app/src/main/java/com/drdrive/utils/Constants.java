package com.drdrive.utils;

/**
 * App-wide constants.
 */
public final class Constants {

    private Constants() {}

    // ── API ───────────────────────────────────────────────────
    public static final int    CONNECT_TIMEOUT_SEC  = 30;
    public static final int    READ_TIMEOUT_SEC     = 60;
    public static final int    WRITE_TIMEOUT_SEC    = 60;

    // ── OBD PIDs ─────────────────────────────────────────────
    public static final String PID_ENGINE_RPM        = "010C";
    public static final String PID_VEHICLE_SPEED     = "010D";
    public static final String PID_COOLANT_TEMP      = "0105";
    public static final String PID_ENGINE_LOAD       = "0104";
    public static final String PID_THROTTLE_POS      = "0111";
    public static final String PID_INTAKE_AIR_TEMP   = "010F";
    public static final String PID_MAF               = "0110";
    public static final String PID_O2_VOLTAGE        = "0114";
    public static final String PID_FUEL_TRIM_ST      = "0106";
    public static final String PID_FUEL_TRIM_LT      = "0107";
    public static final String PID_TIMING_ADVANCE    = "010E";
    public static final String PID_CONTROL_VOLTAGE   = "0142";
    public static final String PID_DTC_COUNT         = "0101";
    public static final String PID_READ_DTC          = "03";

    // ── ELM327 AT Commands ───────────────────────────────────
    public static final String AT_RESET              = "ATZ\r";
    public static final String AT_ECHO_OFF           = "ATE0\r";
    public static final String AT_LINEFEEDS_OFF      = "ATL0\r";
    public static final String AT_AUTO_PROTOCOL      = "ATSP0\r";
    public static final String AT_HEADERS_OFF        = "ATH0\r";

    // ── Camera ────────────────────────────────────────────────
    public static final int    TOTAL_ANGLES          = 6;
    public static final long   MAX_IMAGE_SIZE_BYTES  = 3 * 1024 * 1024; // 3 MB

    // ── WorkManager ──────────────────────────────────────────
    public static final String WORK_TAG_UPLOAD       = "inspection_upload";
    public static final String WORK_KEY_REPORT_ID    = "report_id";

    // ── Shared Prefs ─────────────────────────────────────────
    public static final String PREF_LAST_DEVICE_MAC  = "last_obd_device";
}
