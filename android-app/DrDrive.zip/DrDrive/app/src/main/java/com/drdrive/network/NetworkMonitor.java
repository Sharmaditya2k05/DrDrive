package com.drdrive.network;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

/**
 * NetworkMonitor — exposes a LiveData<Boolean> that is true when
 * the device has an active internet connection.
 *
 * Usage (in ViewModel or Activity):
 *   NetworkMonitor.getInstance(context).isConnected()
 *       .observe(lifecycleOwner, connected -> { ... });
 */
public class NetworkMonitor {

    private static volatile NetworkMonitor instance;

    private final MutableLiveData<Boolean>     connected   = new MutableLiveData<>(false);
    private final ConnectivityManager          cm;
    private final ConnectivityManager.NetworkCallback callback;

    private NetworkMonitor(Context context) {
        cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        callback = new ConnectivityManager.NetworkCallback() {
            @Override
            public void onAvailable(@NonNull Network network) {
                connected.postValue(true);
            }

            @Override
            public void onLost(@NonNull Network network) {
                connected.postValue(false);
            }

            @Override
            public void onUnavailable() {
                connected.postValue(false);
            }
        };

        // Check current state immediately
        connected.setValue(isCurrentlyConnected());

        // Register for future changes
        NetworkRequest request = new NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build();
        cm.registerNetworkCallback(request, callback);
    }

    public static NetworkMonitor getInstance(Context context) {
        if (instance == null) {
            synchronized (NetworkMonitor.class) {
                if (instance == null) {
                    instance = new NetworkMonitor(context.getApplicationContext());
                }
            }
        }
        return instance;
    }

    public LiveData<Boolean> isConnected() { return connected; }

    public boolean isCurrentlyConnected() {
        Network active = cm.getActiveNetwork();
        if (active == null) return false;
        NetworkCapabilities caps = cm.getNetworkCapabilities(active);
        return caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }
}
