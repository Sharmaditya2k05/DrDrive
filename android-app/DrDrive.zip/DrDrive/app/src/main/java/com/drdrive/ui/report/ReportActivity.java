package com.drdrive.ui.report;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.drdrive.databinding.ActivityReportBinding;
import com.drdrive.viewmodel.ReportViewModel;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.ArrayList;

/**
 * ReportActivity — receives OBD session ID + photo paths,
 * triggers backend analysis, shows tabbed results:
 *   Tab 1: Health Score
 *   Tab 2: Damage Detection
 *   Tab 3: Valuation & Cost
 */
public class ReportActivity extends AppCompatActivity {

    public static final String EXTRA_OBD_SESSION_ID = "obd_session_id";
    public static final String EXTRA_PHOTO_PATHS    = "photo_paths";

    private static final String[] TAB_TITLES = {"Health", "Damage", "Valuation"};

    private ActivityReportBinding binding;
    private ReportViewModel reportViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityReportBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Inspection Report");
        }

        reportViewModel = new ViewModelProvider(this).get(ReportViewModel.class);

        extractAndStartAnalysis();
        setupTabs();
        observeViewModel();
    }

    private void extractAndStartAnalysis() {
        String obdSessionId  = getIntent().getStringExtra(EXTRA_OBD_SESSION_ID);
        ArrayList<String> paths = getIntent().getStringArrayListExtra(EXTRA_PHOTO_PATHS);

        binding.analysisOverlay.setVisibility(View.VISIBLE);
        binding.tvAnalysisStatus.setText("Uploading data...");

        reportViewModel.startAnalysis(obdSessionId, paths);
    }

    private void setupTabs() {
        ReportPagerAdapter pagerAdapter = new ReportPagerAdapter(this);
        binding.viewPager.setAdapter(pagerAdapter);
        binding.viewPager.setOffscreenPageLimit(3);  // keep all 3 tabs alive

        new TabLayoutMediator(binding.tabLayout, binding.viewPager,
                (tab, position) -> tab.setText(TAB_TITLES[position])
        ).attach();
    }

    private void observeViewModel() {
        reportViewModel.getAnalysisState().observe(this, state -> {
            switch (state) {
                case UPLOADING:
                    binding.tvAnalysisStatus.setText("Uploading data...");
                    break;
                case ANALYZING:
                    binding.tvAnalysisStatus.setText("AI is analysing your car...");
                    break;
                case COMPLETE:
                    binding.analysisOverlay.setVisibility(View.GONE);
                    break;
                case ERROR:
                    binding.analysisOverlay.setVisibility(View.GONE);
                    Toast.makeText(this, "Analysis failed. Please retry.", Toast.LENGTH_LONG).show();
                    break;
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
