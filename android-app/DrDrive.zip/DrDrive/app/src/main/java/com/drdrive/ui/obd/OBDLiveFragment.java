package com.drdrive.ui.obd;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.drdrive.databinding.FragmentObdLiveBinding;
import com.drdrive.viewmodel.OBDViewModel;

/**
 * OBDLiveFragment — embedded inside OBDScanActivity.
 * Shows real-time gauges: RPM, speed, coolant temp, fuel trims, DTC codes.
 * Hosted via supportFragmentManager inside activity_obd_scan.xml.
 */
public class OBDLiveFragment extends Fragment {

    private FragmentObdLiveBinding binding;
    private OBDViewModel obdViewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentObdLiveBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        obdViewModel = new ViewModelProvider(requireActivity()).get(OBDViewModel.class);
        observeLiveData();
    }

    private void observeLiveData() {
        obdViewModel.getLiveReadings().observe(getViewLifecycleOwner(), reading -> {
            if (reading == null) return;

            // Big gauges
            binding.tvRpmLive.setText(String.valueOf(reading.getRpm()));
            binding.tvSpeedLive.setText(String.valueOf(reading.getSpeed()));

            // Secondary readings — update item_obd_reading sub-views
            setReading(binding.itemCoolant,     "COOLANT",    reading.getCoolantTemp() + " °C");
            setReading(binding.itemEngineLoad,  "LOAD",       String.format("%.1f%%", reading.getEngineLoad()));
            setReading(binding.itemThrottle,    "THROTTLE",   String.format("%.1f%%", reading.getThrottlePosition()));
            setReading(binding.itemBattery,     "BATTERY",    String.format("%.1fV",  reading.getBatteryVoltage()));
            setReading(binding.itemFuelTrimSt,  "ST FUEL TRIM", String.format("%.1f%%", reading.getShortTermFuelTrim()));
            setReading(binding.itemFuelTrimLt,  "LT FUEL TRIM", String.format("%.1f%%", reading.getLongTermFuelTrim()));

            // DTC codes
            if (reading.isMilOn() && reading.getDtcCodes() != null) {
                binding.tvDtcCodes.setText(reading.getDtcCodes());
                binding.tvDtcCodes.setTextColor(
                        requireContext().getColor(com.drdrive.R.color.colorError));
            } else {
                binding.tvDtcCodes.setText("No fault codes detected");
                binding.tvDtcCodes.setTextColor(
                        requireContext().getColor(com.drdrive.R.color.colorSuccess));
            }
        });
    }

    /** Helper to populate a reusable item_obd_reading sub-view. */
    private void setReading(View itemView, String label, String value) {
        if (itemView == null) return;
        android.widget.TextView tvLabel = itemView.findViewById(com.drdrive.R.id.tv_label);
        android.widget.TextView tvValue = itemView.findViewById(com.drdrive.R.id.tv_value);
        if (tvLabel != null) tvLabel.setText(label);
        if (tvValue != null) tvValue.setText(value);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
