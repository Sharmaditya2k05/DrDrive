package com.drdrive.ui.camera;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;

import com.drdrive.databinding.ActivityCameraBinding;
import com.drdrive.ui.report.ReportActivity;
import com.drdrive.utils.PermissionHelper;
import com.drdrive.viewmodel.CameraViewModel;
import com.google.common.util.concurrent.ListenableFuture;

import java.io.File;
import java.util.concurrent.ExecutionException;

/**
 * CameraActivity — guides user through 6 required angles:
 * Front, Rear, Left, Right, Dashboard, Windshield.
 * Each captured image is stored locally then uploaded with the report.
 */
public class CameraActivity extends AppCompatActivity {

    public static final String EXTRA_OBD_SESSION_ID = "obd_session_id";

    // Angle labels in order
    private static final String[] ANGLE_LABELS = {
            "Front view", "Rear view", "Left side",
            "Right side", "Dashboard", "Windshield"
    };

    private ActivityCameraBinding binding;
    private CameraViewModel cameraViewModel;
    private PermissionHelper permissionHelper;

    private ImageCapture imageCapture;
    private int currentAngle = 0;       // 0-5
    private String obdSessionId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCameraBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        obdSessionId = getIntent().getStringExtra(EXTRA_OBD_SESSION_ID);
        cameraViewModel = new ViewModelProvider(this).get(CameraViewModel.class);
        permissionHelper = new PermissionHelper(this);

        permissionHelper.requestCameraPermission(granted -> {
            if (granted) startCamera();
            else {
                Toast.makeText(this, "Camera permission required", Toast.LENGTH_LONG).show();
                finish();
            }
        });

        setupClickListeners();
        observeViewModel();
        updateAngleUI();
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture =
                ProcessCameraProvider.getInstance(this);

        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = cameraProviderFuture.get();

                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(binding.previewView.getSurfaceProvider());

                imageCapture = new ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                        .build();

                cameraProvider.unbindAll();
                cameraProvider.bindToLifecycle(
                        this,
                        CameraSelector.DEFAULT_BACK_CAMERA,
                        preview,
                        imageCapture);

            } catch (ExecutionException | InterruptedException e) {
                Toast.makeText(this, "Camera error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void setupClickListeners() {
        binding.btnCapture.setOnClickListener(v -> capturePhoto());

        binding.btnRetake.setOnClickListener(v -> {
            // Go back one angle
            if (currentAngle > 0) {
                currentAngle--;
                cameraViewModel.removeLastPhoto();
                updateAngleUI();
            }
        });
    }

    private void capturePhoto() {
        if (imageCapture == null) return;

        binding.btnCapture.setEnabled(false);
        binding.progressCapture.setVisibility(View.VISIBLE);

        // Save to app-private cache dir
        File photoFile = new File(getCacheDir(),
                "drdrive_angle_" + currentAngle + "_" + System.currentTimeMillis() + ".jpg");

        ImageCapture.OutputFileOptions options =
                new ImageCapture.OutputFileOptions.Builder(photoFile).build();

        imageCapture.takePicture(
                options,
                ContextCompat.getMainExecutor(this),
                new ImageCapture.OnImageSavedCallback() {
                    @Override
                    public void onImageSaved(@androidx.annotation.NonNull ImageCapture.OutputFileResults output) {
                        Uri savedUri = Uri.fromFile(photoFile);
                        cameraViewModel.addPhoto(currentAngle, savedUri);

                        binding.progressCapture.setVisibility(View.GONE);
                        binding.btnCapture.setEnabled(true);
                        currentAngle++;

                        if (currentAngle >= ANGLE_LABELS.length) {
                            // All 6 angles captured → proceed to analysis
                            proceedToReport();
                        } else {
                            updateAngleUI();
                        }
                    }

                    @Override
                    public void onError(@androidx.annotation.NonNull ImageCaptureException exc) {
                        binding.progressCapture.setVisibility(View.GONE);
                        binding.btnCapture.setEnabled(true);
                        Toast.makeText(CameraActivity.this,
                                "Capture failed: " + exc.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void updateAngleUI() {
        if (currentAngle < ANGLE_LABELS.length) {
            binding.tvAngleLabel.setText(ANGLE_LABELS[currentAngle]);
            binding.tvAngleCounter.setText((currentAngle + 1) + " / " + ANGLE_LABELS.length);
            binding.progressAngles.setProgress((int) ((currentAngle / (float) ANGLE_LABELS.length) * 100));
            binding.btnRetake.setVisibility(currentAngle > 0 ? View.VISIBLE : View.GONE);
        }
    }

    private void observeViewModel() {
        cameraViewModel.getCapturedPhotos().observe(this, photos -> {
            // Thumbnail preview update for last captured photo (optional UX)
        });
    }

    private void proceedToReport() {
        Intent intent = new Intent(this, ReportActivity.class);
        intent.putExtra(ReportActivity.EXTRA_OBD_SESSION_ID, obdSessionId);
        intent.putStringArrayListExtra(
                ReportActivity.EXTRA_PHOTO_PATHS,
                cameraViewModel.getPhotoPathList());
        startActivity(intent);
        finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
