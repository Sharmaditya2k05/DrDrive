package com.drdrive.ui.history;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.drdrive.databinding.FragmentHistoryBinding;
import com.drdrive.viewmodel.ReportViewModel;

/**
 * HistoryFragment — lists all past inspections from Room DB.
 * Full adapter + click → ReportActivity wired in Step 5.
 */
public class HistoryFragment extends Fragment {

    private FragmentHistoryBinding binding;
    private ReportViewModel reportViewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentHistoryBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        reportViewModel = new ViewModelProvider(requireActivity()).get(ReportViewModel.class);

        reportViewModel.getAllInspections().observe(getViewLifecycleOwner(), inspections -> {
            boolean empty = inspections == null || inspections.isEmpty();
            binding.tvEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
            binding.rvHistory.setVisibility(empty ? View.GONE : View.VISIBLE);
            // Full adapter setup in Step 5
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
