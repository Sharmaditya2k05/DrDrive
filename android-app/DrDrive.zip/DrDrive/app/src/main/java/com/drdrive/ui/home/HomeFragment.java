package com.drdrive.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.drdrive.databinding.FragmentHomeBinding;
import com.drdrive.ui.obd.OBDScanActivity;
import com.drdrive.viewmodel.ReportViewModel;

/**
 * HomeFragment — landing screen.
 * Shows welcome card, "Scan Car" CTA, and last 3 inspections summary.
 */
public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private ReportViewModel reportViewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        reportViewModel = new ViewModelProvider(requireActivity()).get(ReportViewModel.class);

        setupScanButton();
        observeRecentInspections();
    }

    private void setupScanButton() {
        binding.btnStartScan.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), OBDScanActivity.class);
            startActivity(intent);
        });

        binding.cardQuickScan.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), OBDScanActivity.class);
            intent.putExtra(OBDScanActivity.EXTRA_QUICK_MODE, true);
            startActivity(intent);
        });
    }

    private void observeRecentInspections() {
        reportViewModel.getRecentInspections().observe(getViewLifecycleOwner(), inspections -> {
            if (inspections == null || inspections.isEmpty()) {
                binding.tvNoHistory.setVisibility(View.VISIBLE);
                binding.rvRecentScans.setVisibility(View.GONE);
            } else {
                binding.tvNoHistory.setVisibility(View.GONE);
                binding.rvRecentScans.setVisibility(View.VISIBLE);
                // Adapter will be wired in Step 5 (History screen)
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
