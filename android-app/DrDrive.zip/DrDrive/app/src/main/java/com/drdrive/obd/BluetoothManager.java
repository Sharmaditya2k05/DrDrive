package com.drdrive.obd;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.drdrive.utils.Constants;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * BluetoothManager — handles ELM327 device discovery and SPP socket connection.
 *
 * ELM327 uses Serial Port Profile (SPP) over Bluetooth Classic.
 * UUID is the standard SPP UUID.
 */
public class BluetoothManager {

    private static final String TAG     = "BTManager";
    private static final UUID   SPP_UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    public interface DiscoveryCallback {
        void onDevicesFound(List<BluetoothDevice> devices);
        void onError(String message);
    }

    public interface ConnectionCallback {
        void onConnected(ELM327Manager elm327);
        void onError(String message);
    }

    private final Context         context;
    private final BluetoothAdapter adapter;
    private final ExecutorService  executor = Executors.newSingleThreadExecutor();

    private BluetoothSocket   activeSocket;
    private ELM327Manager     elm327Manager;

    public BluetoothManager(Context context) {
        this.context = context;
        this.adapter = BluetoothAdapter.getDefaultAdapter();
    }

    // ── Availability checks ──────────────────────────────────

    public boolean isBluetoothAvailable() {
        return adapter != null;
    }

    public boolean isBluetoothEnabled() {
        return adapter != null && adapter.isEnabled();
    }

    // ── Device discovery ─────────────────────────────────────

    /**
     * Returns already-paired devices that look like OBD adapters.
     * Most ELM327 adapters are named "OBDII", "ELM327", "V-LINK" etc.
     * No new pairing needed — user must pair via Android Settings first.
     */
    public void discoverOBDDevices(DiscoveryCallback callback) {
        executor.execute(() -> {
            try {
                Set<BluetoothDevice> paired = adapter.getBondedDevices();
                List<BluetoothDevice> obdDevices = new ArrayList<>();

                for (BluetoothDevice device : paired) {
                    String name = device.getName();
                    if (name != null && isLikelyOBD(name)) {
                        obdDevices.add(device);
                        Log.d(TAG, "Found OBD device: " + name + " [" + device.getAddress() + "]");
                    }
                }

                // Include all paired devices even if name doesn't match —
                // user may have a rebranded adapter
                if (obdDevices.isEmpty()) {
                    obdDevices.addAll(paired);
                }

                callback.onDevicesFound(obdDevices);

            } catch (SecurityException e) {
                callback.onError("Bluetooth permission denied: " + e.getMessage());
            }
        });
    }

    private boolean isLikelyOBD(String name) {
        String upper = name.toUpperCase();
        return upper.contains("OBD")
                || upper.contains("ELM")
                || upper.contains("VLINK")
                || upper.contains("V-LINK")
                || upper.contains("OBDII")
                || upper.contains("SCAN");
    }

    // ── Connection ───────────────────────────────────────────

    /**
     * Connect to a paired device by MAC address and initialise ELM327.
     * Runs on a background thread; callbacks fire on the calling thread's executor.
     */
    public void connectToDevice(String macAddress, ConnectionCallback callback) {
        executor.execute(() -> {
            try {
                BluetoothDevice device = adapter.getRemoteDevice(macAddress);
                Log.d(TAG, "Connecting to " + device.getName() + " (" + macAddress + ")");

                // Cancel discovery to speed up connection
                adapter.cancelDiscovery();

                // Try insecure RFCOMM first (works on most ELM327 clones)
                BluetoothSocket socket;
                try {
                    socket = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
                } catch (SecurityException e) {
                    callback.onError("Bluetooth permission denied");
                    return;
                }

                socket.connect(); // Blocks until connected or throws
                activeSocket = socket;

                Log.d(TAG, "Socket connected — initialising ELM327");
                elm327Manager = new ELM327Manager(socket);
                elm327Manager.initialise();

                // Remember last-used device
                saveLastDevice(macAddress);

                callback.onConnected(elm327Manager);

            } catch (IOException e) {
                Log.e(TAG, "Connection error", e);
                callback.onError("Could not connect: " + e.getMessage()
                        + "\nMake sure the adapter is powered and paired.");
            }
        });
    }

    // ── Saved device ─────────────────────────────────────────

    private void saveLastDevice(String mac) {
        context.getSharedPreferences("drdrive_prefs", Context.MODE_PRIVATE)
                .edit()
                .putString(Constants.PREF_LAST_DEVICE_MAC, mac)
                .apply();
    }

    public String getLastDeviceMac() {
        return context.getSharedPreferences("drdrive_prefs", Context.MODE_PRIVATE)
                .getString(Constants.PREF_LAST_DEVICE_MAC, null);
    }

    // ── Lifecycle ────────────────────────────────────────────

    public void disconnect() {
        if (elm327Manager != null) elm327Manager.close();
        elm327Manager = null;
        activeSocket  = null;
    }

    public boolean isConnected() {
        return elm327Manager != null && elm327Manager.isConnected();
    }

    public ELM327Manager getElm327() { return elm327Manager; }
}
