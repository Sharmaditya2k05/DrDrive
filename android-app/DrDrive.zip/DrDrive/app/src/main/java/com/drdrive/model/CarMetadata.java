package com.drdrive.model;

import com.google.gson.annotations.SerializedName;

/** Basic car info entered by the user before inspection. */
public class CarMetadata {

    @SerializedName("brand")            private String brand;
    @SerializedName("model")            private String model;
    @SerializedName("variant")          private String variant;
    @SerializedName("year")             private int    year;
    @SerializedName("fuel_type")        private String fuelType;       // petrol | diesel | cng | ev
    @SerializedName("transmission")     private String transmission;   // manual | automatic
    @SerializedName("odometer_km")      private int    odometerKm;
    @SerializedName("color")            private String color;
    @SerializedName("registration_no")  private String registrationNo;
    @SerializedName("city")             private String city;

    public String getBrand()          { return brand; }
    public String getModel()          { return model; }
    public String getVariant()        { return variant; }
    public int    getYear()           { return year; }
    public String getFuelType()       { return fuelType; }
    public String getTransmission()   { return transmission; }
    public int    getOdometerKm()     { return odometerKm; }
    public String getColor()          { return color; }
    public String getRegistrationNo() { return registrationNo; }
    public String getCity()           { return city; }

    public void setBrand(String v)          { brand = v; }
    public void setModel(String v)          { model = v; }
    public void setVariant(String v)        { variant = v; }
    public void setYear(int v)              { year = v; }
    public void setFuelType(String v)       { fuelType = v; }
    public void setTransmission(String v)   { transmission = v; }
    public void setOdometerKm(int v)        { odometerKm = v; }
    public void setColor(String v)          { color = v; }
    public void setRegistrationNo(String v) { registrationNo = v; }
    public void setCity(String v)           { city = v; }

    /** Display string for history cards. */
    public String getDisplayName() {
        return year + " " + brand + " " + model;
    }
}
