package com.drdrive.ui.auth;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.drdrive.databinding.ActivityRegisterBinding;
import com.drdrive.ui.MainActivity;
import com.drdrive.viewmodel.AuthViewModel;

public class RegisterActivity extends AppCompatActivity {

    private ActivityRegisterBinding binding;
    private AuthViewModel authViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        authViewModel = new ViewModelProvider(this).get(AuthViewModel.class);
        observeViewModel();
        setupClickListeners();
    }

    private void observeViewModel() {
        authViewModel.getRegisterResult().observe(this, result -> {
            binding.progressBar.setVisibility(View.GONE);
            if (result.isSuccess()) {
                Toast.makeText(this, "Account created! Please login.", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, result.getError(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void setupClickListeners() {
        binding.btnRegister.setOnClickListener(v -> {
            String name     = binding.etName.getText().toString().trim();
            String email    = binding.etEmail.getText().toString().trim();
            String password = binding.etPassword.getText().toString().trim();
            String confirm  = binding.etConfirmPassword.getText().toString().trim();

            if (TextUtils.isEmpty(name)) { binding.etName.setError("Name required"); return; }
            if (TextUtils.isEmpty(email)) { binding.etEmail.setError("Email required"); return; }
            if (password.length() < 6) { binding.etPassword.setError("Min 6 characters"); return; }
            if (!password.equals(confirm)) { binding.etConfirmPassword.setError("Passwords don't match"); return; }

            binding.progressBar.setVisibility(View.VISIBLE);
            authViewModel.register(name, email, password);
        });

        binding.tvLogin.setOnClickListener(v -> finish());
    }
}
