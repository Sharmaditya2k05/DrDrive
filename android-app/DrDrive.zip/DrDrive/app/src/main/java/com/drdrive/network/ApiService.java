package com.drdrive.network;

import com.drdrive.model.InspectionReport;

import java.util.List;
import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.PartMap;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * ApiService — every backend endpoint as a Retrofit interface.
 *
 * Base URL set in BuildConfig.BASE_URL:
 *   Debug:   http://10.0.2.2:8000/    (Android emulator → localhost)
 *   Release: https://api.drdrive.in/
 */
public interface ApiService {

    // ── Auth ─────────────────────────────────────────────────

    @POST("api/auth/login")
    Call<AuthResponse> login(@Body LoginRequest request);

    @POST("api/auth/register")
    Call<AuthResponse> register(@Body RegisterRequest request);

    @POST("api/auth/logout")
    Call<Void> logout();

    // ── Inspection ───────────────────────────────────────────

    /**
     * Upload OBD JSON + 6 car images as multipart form.
     * Returns a report_id for polling.
     */
    @Multipart
    @POST("api/inspection/create")
    Call<CreateInspectionResponse> createInspection(
            @PartMap Map<String, RequestBody>   fields,
            @Part   List<MultipartBody.Part>    images
    );

    /**
     * Poll analysis status by report_id.
     * Returns full InspectionReport when status == "complete".
     */
    @GET("api/inspection/{report_id}")
    Call<InspectionReport> getReport(@Path("report_id") String reportId);

    /**
     * List all inspections for the current user.
     */
    @GET("api/inspection/list")
    Call<List<InspectionReport>> listInspections(
            @Query("page")     int page,
            @Query("per_page") int perPage
    );

    // ── Request / Response inner classes ─────────────────────

    class LoginRequest {
        public final String email;
        public final String password;
        public LoginRequest(String email, String password) {
            this.email    = email;
            this.password = password;
        }
    }

    class RegisterRequest {
        public final String name;
        public final String email;
        public final String password;
        public RegisterRequest(String name, String email, String password) {
            this.name     = name;
            this.email    = email;
            this.password = password;
        }
    }

    class AuthResponse {
        public String token;
        public String name;
        public String email;
        public String message;
    }

    class CreateInspectionResponse {
        public String  report_id;
        public String  status;   // "processing"
        public String  message;
    }
}
