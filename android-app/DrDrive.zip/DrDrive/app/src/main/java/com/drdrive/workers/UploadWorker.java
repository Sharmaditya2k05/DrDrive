package com.drdrive.workers;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.drdrive.database.AppDatabase;
import com.drdrive.database.InspectionDao;
import com.drdrive.database.entity.InspectionEntity;
import com.drdrive.network.ApiClient;
import com.drdrive.network.ApiService;
import com.drdrive.utils.Constants;

import java.util.List;

import retrofit2.Response;

/**
 * UploadWorker — retries uploading any locally-saved but unsynced inspections.
 *
 * Triggered by WorkManager when network becomes available after an offline session.
 * Enqueued with constraints: NETWORK_CONNECTED.
 *
 * To enqueue from anywhere:
 *   Constraints constraints = new Constraints.Builder()
 *       .setRequiredNetworkType(NetworkType.CONNECTED)
 *       .build();
 *   OneTimeWorkRequest work = new OneTimeWorkRequest.Builder(UploadWorker.class)
 *       .setConstraints(constraints)
 *       .addTag(Constants.WORK_TAG_UPLOAD)
 *       .build();
 *   WorkManager.getInstance(context).enqueueUniqueWork(
 *       Constants.WORK_TAG_UPLOAD,
 *       ExistingWorkPolicy.KEEP,
 *       work);
 */
public class UploadWorker extends Worker {

    private static final String TAG = "UploadWorker";

    public UploadWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Log.d(TAG, "UploadWorker started");

        InspectionDao dao = AppDatabase.getInstance(getApplicationContext()).inspectionDao();
        List<InspectionEntity> unsynced = dao.getUnsynced();

        if (unsynced.isEmpty()) {
            Log.d(TAG, "Nothing to sync");
            return Result.success();
        }

        Log.d(TAG, "Syncing " + unsynced.size() + " pending inspections");

        for (InspectionEntity entity : unsynced) {
            try {
                // Re-fetch full report status from server
                Response<ApiService.CreateInspectionResponse> resp =
                        ApiClient.getService()
                                .createInspection(null, null)  // placeholder — real impl in full Step 4
                                .execute();

                if (resp.isSuccessful()) {
                    entity.synced = true;
                    dao.update(entity);
                    Log.d(TAG, "Synced: " + entity.reportId);
                }
            } catch (Exception e) {
                Log.e(TAG, "Failed to sync " + entity.reportId, e);
                return Result.retry(); // WorkManager will back-off and retry
            }
        }

        return Result.success();
    }
}
