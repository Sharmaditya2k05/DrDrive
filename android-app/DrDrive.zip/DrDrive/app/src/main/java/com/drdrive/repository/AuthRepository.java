package com.drdrive.repository;

import android.content.Context;

import com.drdrive.network.ApiClient;
import com.drdrive.network.ApiService;
import com.drdrive.utils.SessionManager;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Response;

/**
 * AuthRepository — login / register, token storage, session management.
 */
public class AuthRepository {

    public interface AuthCallback {
        void onSuccess(String token, String name, String email);
        void onError(String message);
    }

    private final SessionManager  session;
    private final ApiService      api;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public AuthRepository(Context context) {
        this.session = new SessionManager(context);
        this.api     = ApiClient.getService();
    }

    // ── Login ─────────────────────────────────────────────────

    public void login(String email, String password, AuthCallback callback) {
        executor.execute(() -> {
            try {
                Response<ApiService.AuthResponse> response =
                        api.login(new ApiService.LoginRequest(email, password)).execute();

                if (response.isSuccessful() && response.body() != null) {
                    ApiService.AuthResponse body = response.body();
                    session.saveSession(body.token, body.name, body.email);
                    ApiClient.setToken(body.token);
                    callback.onSuccess(body.token, body.name, body.email);
                } else {
                    callback.onError(parseError(response.code()));
                }
            } catch (Exception e) {
                callback.onError("Network error: " + e.getMessage());
            }
        });
    }

    // ── Register ──────────────────────────────────────────────

    public void register(String name, String email, String password, AuthCallback callback) {
        executor.execute(() -> {
            try {
                Response<ApiService.AuthResponse> response =
                        api.register(new ApiService.RegisterRequest(name, email, password)).execute();

                if (response.isSuccessful() && response.body() != null) {
                    callback.onSuccess("", name, email);
                } else {
                    callback.onError(parseError(response.code()));
                }
            } catch (Exception e) {
                callback.onError("Network error: " + e.getMessage());
            }
        });
    }

    // ── Helpers ───────────────────────────────────────────────

    private String parseError(int code) {
        switch (code) {
            case 401: return "Invalid email or password.";
            case 409: return "Email already registered.";
            case 422: return "Please check your input.";
            case 500: return "Server error. Please try again.";
            default:  return "Error " + code + ". Please try again.";
        }
    }
}
