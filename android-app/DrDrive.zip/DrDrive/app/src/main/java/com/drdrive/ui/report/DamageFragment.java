package com.drdrive.ui.report;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.drdrive.databinding.FragmentDamageBinding;
import com.drdrive.viewmodel.ReportViewModel;

/**
 * DamageFragment — Tab 2.
 * Shows detected dents / scratches / cracks per image angle.
 * Full image overlay renderer added in Step 6.
 */
public class DamageFragment extends Fragment {

    private FragmentDamageBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentDamageBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ReportViewModel vm = new ViewModelProvider(requireActivity()).get(ReportViewModel.class);

        binding.rvDamages.setLayoutManager(new LinearLayoutManager(requireContext()));

        vm.getDamageResults().observe(getViewLifecycleOwner(), damages -> {
            if (damages == null || damages.isEmpty()) {
                binding.tvNoDamage.setVisibility(View.VISIBLE);
                binding.rvDamages.setVisibility(View.GONE);
            } else {
                binding.tvNoDamage.setVisibility(View.GONE);
                binding.rvDamages.setVisibility(View.VISIBLE);
                binding.tvDamageCount.setText(damages.size() + " issue(s) detected");
                // DamageAdapter wired in Step 6
            }
        });
    }

    @Override
    public void onDestroyView() { super.onDestroyView(); binding = null; }
}
