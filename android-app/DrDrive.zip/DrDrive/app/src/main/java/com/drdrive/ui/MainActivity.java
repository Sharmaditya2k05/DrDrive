package com.drdrive.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.drdrive.R;
import com.drdrive.databinding.ActivityMainBinding;
import com.drdrive.ui.obd.OBDScanActivity;

/**
 * MainActivity — single-activity shell that hosts the Jetpack NavGraph.
 * Bottom navigation switches between Home, History, and Profile fragments.
 * The FAB launches the full OBD scan → Camera → Report flow.
 */
public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private NavController navController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setupNavigation();
        setupFab();
    }

    private void setupNavigation() {
        navController = Navigation.findNavController(this, R.id.nav_host_fragment);

        // Top-level destinations — no back arrow shown for these
        AppBarConfiguration appBarConfig = new AppBarConfiguration.Builder(
                R.id.nav_home,
                R.id.nav_history,
                R.id.nav_profile
        ).build();

        // Wire toolbar
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfig);

        // Wire bottom nav
        NavigationUI.setupWithNavController(binding.bottomNav, navController);

        // Hide/show bottom nav based on destination
        navController.addOnDestinationChangedListener((ctrl, dest, args) -> {
            boolean isTopLevel = dest.getId() == R.id.nav_home
                    || dest.getId() == R.id.nav_history
                    || dest.getId() == R.id.nav_profile;
            binding.bottomNav.setVisibility(isTopLevel
                    ? android.view.View.VISIBLE
                    : android.view.View.GONE);
        });
    }

    private void setupFab() {
        // FAB starts the inspection flow: OBD scan → Camera → Report
        binding.fabScan.setOnClickListener(v -> {
            Intent intent = new Intent(this, OBDScanActivity.class);
            startActivity(intent);
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        return navController.navigateUp() || super.onSupportNavigateUp();
    }
}
