package com.drdrive.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.drdrive.model.DamageResult;
import com.drdrive.model.HealthScore;
import com.drdrive.model.InspectionReport;
import com.drdrive.model.Valuation;

import java.util.List;

/**
 * ReportViewModel — drives ReportActivity and all three tabs.
 * Calls InspectionRepository.analyse() and exposes result streams.
 * Full network call wired in Step 4 (API client).
 */
public class ReportViewModel extends AndroidViewModel {

    public enum AnalysisState { IDLE, UPLOADING, ANALYZING, COMPLETE, ERROR }

    private final MutableLiveData<AnalysisState>     analysisState  = new MutableLiveData<>(AnalysisState.IDLE);
    private final MutableLiveData<HealthScore>        healthScore    = new MutableLiveData<>();
    private final MutableLiveData<List<DamageResult>> damageResults  = new MutableLiveData<>();
    private final MutableLiveData<Valuation>          valuation      = new MutableLiveData<>();

    // For HomeFragment recent list and HistoryFragment full list
    private final MutableLiveData<List<InspectionReport>> recentInspections = new MutableLiveData<>();
    private final MutableLiveData<List<InspectionReport>> allInspections    = new MutableLiveData<>();

    public ReportViewModel(@NonNull Application application) {
        super(application);
    }

    /**
     * Entry point: upload OBD session + photos → poll for result.
     * Step 4 will replace the stub body with real Retrofit calls.
     */
    public void startAnalysis(String obdSessionId, List<String> photoPaths) {
        analysisState.setValue(AnalysisState.UPLOADING);

        // TODO Step 4: InspectionRepository.startAnalysis(obdSessionId, photoPaths)
        //   .observe → post results into LiveData fields below

        // Stub: simulate analysis complete after 3 seconds for UI testing
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
            postStubData();
        }, 3000);
    }

    /** Stub data so UI renders during development — remove after Step 4. */
    private void postStubData() {
        HealthScore hs = new HealthScore();
        hs.setOverallScore(72);
        hs.setEngineHealth(80);
        hs.setTransmissionHealth(75);
        hs.setBatteryHealth(65);
        hs.setEmissionHealth(70);
        healthScore.setValue(hs);

        Valuation v = new Valuation();
        v.setFairMarketValue(385000);
        v.setRepairCostMin(12000);
        v.setRepairCostMax(25000);
        v.setAdjustedValue(363000);
        v.setFraudSuspected(false);
        valuation.setValue(v);

        analysisState.setValue(AnalysisState.COMPLETE);
    }

    public void loadRecentInspections()  { /* Step 4: Room DAO query */ }
    public void loadAllInspections()     { /* Step 4: Room DAO query */ }

    public LiveData<AnalysisState>          getAnalysisState()    { return analysisState; }
    public LiveData<HealthScore>            getHealthScore()       { return healthScore; }
    public LiveData<List<DamageResult>>     getDamageResults()     { return damageResults; }
    public LiveData<Valuation>              getValuation()         { return valuation; }
    public LiveData<List<InspectionReport>> getRecentInspections() { return recentInspections; }
    public LiveData<List<InspectionReport>> getAllInspections()     { return allInspections; }
}
