package com.drdrive.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * ImageUtils — compresses captured car images before upload.
 *
 * Target: ≤ 1 MB per image (backend max is 3 MB but smaller = faster upload).
 * Preserves EXIF rotation so images display correctly server-side.
 */
public class ImageUtils {

    private static final String TAG            = "ImageUtils";
    private static final int    TARGET_WIDTH   = 1280;  // px
    private static final int    TARGET_HEIGHT  = 960;   // px
    private static final int    JPEG_QUALITY   = 80;    // percent

    /**
     * Read a Uri, rotate if needed, resize to 1280×960, compress to JPEG.
     *
     * @param context    needed to open the content Uri
     * @param uri        source image (file:// or content://)
     * @param angleIndex used to name the output file
     * @return           compressed File, or null on failure
     */
    public static File compressImage(Context context, Uri uri, int angleIndex) {
        try {
            // Decode bounds first to calculate sample size (avoid OOM)
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            decodeBounds(context, uri, options);

            options.inSampleSize    = calculateSampleSize(options, TARGET_WIDTH, TARGET_HEIGHT);
            options.inJustDecodeBounds = false;

            Bitmap bitmap = decodeBitmap(context, uri, options);
            if (bitmap == null) return null;

            // Fix rotation from EXIF
            bitmap = fixRotation(context, uri, bitmap);

            // Scale to target dimensions
            bitmap = scaleBitmap(bitmap, TARGET_WIDTH, TARGET_HEIGHT);

            // Write to cache
            File outFile = new File(context.getCacheDir(),
                    "upload_angle_" + angleIndex + ".jpg");
            try (FileOutputStream fos = new FileOutputStream(outFile)) {
                bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, fos);
            }
            bitmap.recycle();

            Log.d(TAG, "Compressed angle " + angleIndex
                    + " → " + outFile.length() / 1024 + " KB");
            return outFile;

        } catch (Exception e) {
            Log.e(TAG, "Compression failed for angle " + angleIndex, e);
            return null;
        }
    }

    // ── Internal helpers ─────────────────────────────────────

    private static void decodeBounds(Context ctx, Uri uri, BitmapFactory.Options opts)
            throws IOException {
        try (InputStream is = ctx.getContentResolver().openInputStream(uri)) {
            BitmapFactory.decodeStream(is, null, opts);
        }
    }

    private static Bitmap decodeBitmap(Context ctx, Uri uri, BitmapFactory.Options opts)
            throws IOException {
        try (InputStream is = ctx.getContentResolver().openInputStream(uri)) {
            return BitmapFactory.decodeStream(is, null, opts);
        }
    }

    private static int calculateSampleSize(BitmapFactory.Options opts, int reqW, int reqH) {
        int h = opts.outHeight, w = opts.outWidth, size = 1;
        if (h > reqH || w > reqW) {
            int halfH = h / 2, halfW = w / 2;
            while ((halfH / size) >= reqH && (halfW / size) >= reqW) size *= 2;
        }
        return size;
    }

    private static Bitmap fixRotation(Context ctx, Uri uri, Bitmap bm) {
        try (InputStream is = ctx.getContentResolver().openInputStream(uri)) {
            if (is == null) return bm;
            ExifInterface exif = new ExifInterface(is);
            int orientation = exif.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL);

            Matrix matrix = new Matrix();
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:  matrix.postRotate(90);  break;
                case ExifInterface.ORIENTATION_ROTATE_180: matrix.postRotate(180); break;
                case ExifInterface.ORIENTATION_ROTATE_270: matrix.postRotate(270); break;
                default: return bm;
            }
            Bitmap rotated = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(),
                    matrix, true);
            bm.recycle();
            return rotated;

        } catch (IOException e) {
            Log.w(TAG, "EXIF read failed — skipping rotation fix");
            return bm;
        }
    }

    private static Bitmap scaleBitmap(Bitmap src, int maxW, int maxH) {
        int w = src.getWidth(), h = src.getHeight();
        if (w <= maxW && h <= maxH) return src;

        float scale = Math.min((float) maxW / w, (float) maxH / h);
        int newW = Math.round(w * scale), newH = Math.round(h * scale);
        Bitmap scaled = Bitmap.createScaledBitmap(src, newW, newH, true);
        src.recycle();
        return scaled;
    }
}
