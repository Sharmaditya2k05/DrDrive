package com.drdrive.obd;

import android.util.Log;

import com.drdrive.model.OBDReading;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * OBDDataCollector — continuously polls all PIDs at a fixed interval
 * and delivers a fresh OBDReading to the caller via callback.
 *
 * Also runs a one-time DTC read at startup.
 */
public class OBDDataCollector {

    private static final String TAG          = "OBDCollector";
    private static final long   POLL_RATE_MS = 500; // poll every 500ms

    public interface ReadingCallback {
        void onReading(OBDReading reading);
        void onDTCs(List<String> dtcCodes);
        void onError(String message);
    }

    private final ELM327Manager          elm327;
    private final ReadingCallback         callback;
    private final ScheduledExecutorService scheduler =
            Executors.newSingleThreadScheduledExecutor();

    private ScheduledFuture<?> pollTask;
    private boolean            running = false;

    public OBDDataCollector(ELM327Manager elm327, ReadingCallback callback) {
        this.elm327   = elm327;
        this.callback = callback;
    }

    // ── Control ──────────────────────────────────────────────

    /**
     * Start polling all PIDs.
     * Reads DTCs once immediately, then polls live data at POLL_RATE_MS.
     */
    public void start() {
        if (running) return;
        running = true;

        // Read DTCs first (one-time, blocking)
        scheduler.execute(() -> {
            try {
                List<String> dtcs = elm327.readDTCs();
                callback.onDTCs(dtcs);
                Log.d(TAG, "DTCs: " + dtcs);
            } catch (IOException e) {
                Log.e(TAG, "DTC read failed", e);
            }
        });

        // Then start live polling
        pollTask = scheduler.scheduleAtFixedRate(
                this::pollOnce,
                200,
                POLL_RATE_MS,
                TimeUnit.MILLISECONDS);

        Log.d(TAG, "Polling started at " + POLL_RATE_MS + "ms interval");
    }

    public void stop() {
        running = false;
        if (pollTask != null) pollTask.cancel(false);
        scheduler.shutdown();
        Log.d(TAG, "Polling stopped");
    }

    // ── Poll loop ────────────────────────────────────────────

    private void pollOnce() {
        if (!running || !elm327.isConnected()) return;

        OBDReading reading = new OBDReading();
        reading.setTimestamp(System.currentTimeMillis());

        try {
            float rpm = elm327.read(OBDCommand.ENGINE_RPM);
            if (!Float.isNaN(rpm)) reading.setRpm((int) rpm);

            float speed = elm327.read(OBDCommand.VEHICLE_SPEED);
            if (!Float.isNaN(speed)) reading.setSpeed((int) speed);

            float coolant = elm327.read(OBDCommand.COOLANT_TEMP);
            if (!Float.isNaN(coolant)) reading.setCoolantTemp((int) coolant);

            float load = elm327.read(OBDCommand.ENGINE_LOAD);
            if (!Float.isNaN(load)) reading.setEngineLoad(load);

            float throttle = elm327.read(OBDCommand.THROTTLE_POSITION);
            if (!Float.isNaN(throttle)) reading.setThrottlePosition(throttle);

            float intakeTemp = elm327.read(OBDCommand.INTAKE_AIR_TEMP);
            if (!Float.isNaN(intakeTemp)) reading.setIntakeAirTemp((int) intakeTemp);

            float stFuelTrim = elm327.read(OBDCommand.SHORT_FUEL_TRIM_B1);
            if (!Float.isNaN(stFuelTrim)) reading.setShortTermFuelTrim(stFuelTrim);

            float ltFuelTrim = elm327.read(OBDCommand.LONG_FUEL_TRIM_B1);
            if (!Float.isNaN(ltFuelTrim)) reading.setLongTermFuelTrim(ltFuelTrim);

            float voltage = elm327.read(OBDCommand.CONTROL_MODULE_VOLTAGE);
            if (!Float.isNaN(voltage)) reading.setBatteryVoltage(voltage);

            float o2 = elm327.read(OBDCommand.O2_VOLTAGE_B1S1);
            if (!Float.isNaN(o2)) reading.setO2Voltage(o2);

            float maf = elm327.read(OBDCommand.MAF_RATE);
            if (!Float.isNaN(maf)) reading.setMaf(maf);

            float timing = elm327.read(OBDCommand.TIMING_ADVANCE);
            if (!Float.isNaN(timing)) reading.setTimingAdvance(timing);

            float dtcCount = elm327.read(OBDCommand.DTC_COUNT);
            if (!Float.isNaN(dtcCount)) {
                reading.setDtcCount((int) dtcCount);
                reading.setMilOn(dtcCount > 0);
            }

            callback.onReading(reading);

        } catch (IOException e) {
            Log.e(TAG, "Poll error", e);
            if (running) callback.onError("OBD read error: " + e.getMessage());
        }
    }

    /**
     * Collect a fixed number of readings and return the average.
     * Used to build the snapshot sent to the backend.
     */
    public OBDReading collectSnapshot(int sampleCount, long intervalMs) {
        OBDReading[] samples = new OBDReading[sampleCount];
        for (int i = 0; i < sampleCount; i++) {
            pollOnce();
            // Give last reading time to arrive
            try { Thread.sleep(intervalMs); } catch (InterruptedException ignored) {}
        }
        // Return latest reading — averaging done server-side
        return samples[sampleCount - 1];
    }
}
